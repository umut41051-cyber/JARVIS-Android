# JARVIS Android

İlk Android sürümü: koyu/mavi arayüz, Türkçe TTS, sesli komut girişi, saat/tarih, selamlaşma ve basit uygulama açma.

## Derleme
Android Gradle Plugin 8.7.3, Gradle 8.9, JDK 17 ve Android SDK 35 kullanılır.
GitHub Actions iş akışı `.github/workflows/android.yml` dosyasıyla kurulabilir.

Not: Bu sürümde çevrimiçi sohbet/LLM bağlantısı, hava durumu ve sürekli uyandırma sözcüğü henüz yoktur. Ses tanıma, cihazdaki tanıma hizmetine bağlıdır.
