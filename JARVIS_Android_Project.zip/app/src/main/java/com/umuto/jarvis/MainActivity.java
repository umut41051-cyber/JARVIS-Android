package com.umuto.jarvis;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.graphics.Color;
import android.graphics.Typeface;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private TextView status, answer;
    private EditText input;
    private TextToSpeech tts;
    private static final int SPEECH_REQUEST = 41;
    private final int bg = Color.rgb(5, 10, 20);
    private final int blue = Color.rgb(0, 190, 255);

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) {
                tts.setLanguage(new Locale("tr", "TR"));
                tts.setSpeechRate(0.88f);
            }
        });
        buildScreen();
        speak("İyi akşamlar, Efendim. JARVIS hazır.");
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 34, 24, 24);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(bg);
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("J.A.R.V.I.S");
        title.setTextColor(blue);
        title.setTextSize(34);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title, matchWrap());

        TextView subtitle = new TextView(this);
        subtitle.setText("PERSONAL ASSISTANT  •  ONLINE / OFFLINE");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setTextSize(11);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, 8, 0, 26);
        root.addView(subtitle, matchWrap());

        status = new TextView(this);
        status.setText("● SYSTEM READY");
        status.setTextColor(blue);
        status.setTextSize(14);
        status.setGravity(Gravity.CENTER);
        status.setPadding(12, 18, 12, 18);
        root.addView(status, matchWrap());

        answer = new TextView(this);
        answer.setText("İyi akşamlar, Efendim. Size nasıl yardımcı olabilirim?");
        answer.setTextColor(Color.WHITE);
        answer.setTextSize(18);
        answer.setGravity(Gravity.CENTER);
        answer.setPadding(10, 26, 10, 26);
        root.addView(answer, matchWrap());

        input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("JARVIS'a bir komut yazın...");
        input.setHintTextColor(Color.GRAY);
        input.setTextColor(Color.WHITE);
        input.setTextSize(16);
        input.setPadding(16, 14, 16, 14);
        input.setBackgroundTintList(android.content.res.ColorStateList.valueOf(blue));
        root.addView(input, matchWrap());

        Button send = makeButton("KOMUTU GÖNDER");
        root.addView(send, matchWrap());
        send.setOnClickListener(v -> handle(input.getText().toString()));

        Button mic = makeButton("🎙  SESLİ KOMUT");
        root.addView(mic, matchWrap());
        mic.setOnClickListener(v -> listen());

        Button time = makeButton("SAAT VE TARİH");
        root.addView(time, matchWrap());
        time.setOnClickListener(v -> handle("saat kaç"));

        TextView note = new TextView(this);
        note.setText("İlk sürüm: temel komutlar ve sesli yanıt. İnternet tabanlı yapay zekâ henüz bağlı değil.");
        note.setTextColor(Color.GRAY);
        note.setTextSize(12);
        note.setGravity(Gravity.CENTER);
        note.setPadding(8, 24, 8, 8);
        root.addView(note, matchWrap());

        setContentView(scroll);
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(-1, -2);
    }

    private Button makeButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(14);
        b.setAllCaps(false);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(10, 55, 85)));
        LinearLayout.LayoutParams p = matchWrap();
        p.setMargins(0, 10, 0, 4);
        b.setLayoutParams(p);
        return b;
    }

    private void listen() {
        try {
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR");
            i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Efendim, sizi dinliyorum.");
            startActivityForResult(i, SPEECH_REQUEST);
        } catch (Exception e) {
            show("Bu cihazda ses tanıma hizmeti bulunamadı.");
        }
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == SPEECH_REQUEST && result == RESULT_OK && data != null) {
            ArrayList<String> matches = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (matches != null && !matches.isEmpty()) {
                input.setText(matches.get(0));
                handle(matches.get(0));
            }
        }
    }

    private void handle(String raw) {
        String q = raw == null ? "" : raw.toLowerCase(new Locale("tr", "TR")).trim();
        if (q.isEmpty()) { show("Efendim, komutunuzu bekliyorum."); return; }
        if (q.contains("saat") || q.contains("tarih") || q.contains("bugün")) {
            String now = new SimpleDateFormat("HH:mm, dd MMMM yyyy", new Locale("tr", "TR")).format(new Date());
            show("Şu an " + now + ", Efendim.");
        } else if (q.contains("merhaba") || q.contains("selam") || q.contains("nasılsın")) {
            show("Sistemlerim çalışır durumda, Efendim. Size nasıl yardımcı olabilirim?");
        } else if (q.contains("yardım") || q.contains("neler yap")) {
            show("Saat ve tarihi söyleyebilirim, selamlaşabilirim ve uygulama açma komutlarını deneyebilirim, Efendim.");
        } else if (q.startsWith("aç ")) {
            launchApp(q.substring(3).trim());
        } else {
            show("Bu komut ilk sürümde tanımlı değil, Efendim. Saat, tarih veya yardım komutunu deneyin.");
        }
    }

    private void launchApp(String name) {
        if (name.isEmpty()) { show("Hangi uygulamayı açmamı istersiniz, Efendim?"); return; }
        try {
            android.content.pm.PackageManager pm = getPackageManager();
            Intent main = new Intent(Intent.ACTION_MAIN, null);
            main.addCategory(Intent.CATEGORY_LAUNCHER);
            List<android.content.pm.ResolveInfo> apps = pm.queryIntentActivities(main, 0);
            for (android.content.pm.ResolveInfo app : apps) {
                String label = app.loadLabel(pm).toString();
                if (label.toLowerCase(new Locale("tr", "TR")).contains(name)) {
                    Intent launch = pm.getLaunchIntentForPackage(app.activityInfo.packageName);
                    if (launch != null) { startActivity(launch); show(label + " açılıyor, Efendim."); return; }
                }
            }
            show(name + " adlı uygulamayı bulamadım, Efendim.");
        } catch (Exception e) { show("Uygulama açılamadı, Efendim."); }
    }

    private void show(String message) {
        answer.setText(message);
        status.setText("● READY  /  COMMAND RECEIVED");
        speak(message);
    }

    private void speak(String message) {
        if (tts != null) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply");
    }

    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}
